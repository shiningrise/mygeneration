HelpNDoc Version 1.11
---------------------

This file contains useful information about HelpNDoc, an easy to use yet
powerful and intuitive tool to create html help files.

== CONTENTS ====================================================================

  1. Welcome!
  2. System Requirements
  3. Installing HelpNDoc
  4. First steps with HelpNDoc
  5. Purchasing HelpNDoc
  6. Version Information
  7. Obtaining technical support

== 1. Welcome ==================================================================

IBE Software would like to welcome you to HelpNDoc. We, at IBE Software, 
believe that you will never see the creation of help files the same way 
as before using HelpNDoc.

== 2. System Requirements ======================================================

  -> Minimum configuration:
      - Any system running Windows 95 (or higher) operating system 
      - 10MB of free disk space

  -> Recommended Configuration:
      - Windows 98 or higher operating system
      - Pentium 166Mhz
      - 32MB of RAM 
      - 20MB of free disk space

You will also need these software (See the help file to obtain more information)
      - Help Viewer: HTML Help Viewer (only required for Windows 95)
      - Help Compiler: HTML Help Workshop (required on all systems)

== 3. Installing HelpNDoc ======================================================

Just run the HelpNDoc.exe file and follow the instructions. You can install
HelpNDoc over a previously installed version.

== 4. First steps with HelpNDoc ================================================

You can use the help file to help you get started with the environment.

== 5. Purchasing HelpNDoc ======================================================

You can find more information about ordering HelpNDoc by following this link:
http://www.helpndoc.com/buy.php

== 6. Version Information ======================================================

  -> v1.11 � 22/07/2007

     * Fixed the export of background images in the topics
     + Possibility to use subscript and superscript formatting options
     * Various bug fixes

  -> v1.10 � 28/05/2007
  
     * Better Windows Vista compatibility
     * Fixed HelpNDoc's help file display exception under Windows Vista
     * Fix for the & character in project title when exporting to CHM
     * Right Alt + A was selecting all the topic's text and caused problems with
       certain keyboard layouts
     * Lower memory usage for GIF images
     * Better table support
     * Better HTML Import / Export
     * Topic Editor enhancements and bug fixes

  -> v1.9 � 30/05/2006
  
     + Double click to modify image property in the topic editor
     * Live spell checker could take 100% CPU time on certain condition
     + Support of relative URLs when exporting
     * Hyperlink images do not show borders anymore
     * Topic margins and page size could be incorrectly set from the ruler
       resulting in inconsistent layouts
     + Interface layout is now saved between sessions
     * Fixed a bug with relative hyperlinks in HTML export

  -> v1.8 - 14/03/2006
  
     + The live spell checker can now be disabled
     + Possibility to automatically generate the context number for new topics
     + Added cut/copy/paste of nodes within the same project
     * Fixed accentuated characters export for Western code pages
     + Right click to add the selection as a keyword in the topic editor
     + Multi selection for drag and drop and node copying
     * Removed the popup window when using HelpNDoc from command line
     * Fixed Incorrect menu animation
     * Fixed Access Violation when CTRL + Drag a node
     * Now generates a valid Delphi unit with proper interface and
       implementation sections
     + File overwrite confirmation when generating code

  -> v1.7 - 01/02/2006
  
     * Better Unicode compliance
     + Vastly improved command line interface. See help file for details
     * Updated project pane layout
     * Possible TOC corruption: project title wasn't correctly escaped in HTML
       output
     + Optionally clean the "Files" sub-directory in HTML export
     + Link to easily download HTML Help Workshop in the compiler output if it's
       not installed on the computer
     * Various enhancements in the topic editor

  -> v1.6.1 - 07/11/2005  
  
     * Icons were not exported in CHM help file anymore
     * CTRL-A shortcut didn't work anymore
     * Fixed some memory leaks
  
  -> v1.6 - 17/10/2005

     * Internet Explorer complained about an invalid character when viewing an
       Help Web Site
     * Improved hyperlink window�s appearance for better consistency throughout
       the application and added shortcuts
     * Improved the speed of creation of spell checking suggestions
     * Keyword�s root could be deleted which could cause unexpected behaviour
     + Possibility to add a subject to e-mail hyperlinks
     + New kind of hyperlinks: navigation, to go to next, previous, parent...
     * Insert hyperlink field was truncated to 30 characters
     * Keywords associated with multiple topics showed "untitled" topics in
       popup window
     + Added shortcuts CTRL + ARROW to move items in the TOC
     * Help file has been updated
  
  -> v1.5 - 05/09/2005
  
     + Introducing a basic HTML Export functionality
     + Generate Visual Basic, C++ and Delphi constants for easier integration of
       the help file with programming languages
     * Fixed a MS HTML Viewer bug which could display an error message when
       opening a CHM file
     * Fixed a bug with topic ID modification in the topic editor

  -> v1.4 - 27/07/2005
  
     * Typing in the topic editor could become extremely slow and HND file could
       grow exponentially. The fix will be applied topic by topic once edited
       and saved
     + Added anchors and possibility to link to them
     + Enhanced link window with new links to anchors, file with or without
       relative paths, topics, Internet or e-mail
     + Variables now display hints with current value
     + Shortcut to add an hyperlink: CTRL+L
     + Default topic font can now be defined in the project properties
     * General application speed boost

  -> v1.3 - 23/05/2005
  
     * Internal HND format has been fine-tuned to provide better speed and size.
       Gain is proportional to project complexity but for reference:
       - For a simple help file such as the one from HelpNDoc, the loading time
         is divided by 2 and the file size is only 70% of the original;
       - For a bigger file, the loading is 30 times faster for a size of 64% of
         the original.
     * Search and replace algorithm have been optimized. Speed is 6 times faster
       for a small size project and increases with project size.
     + Possibility to change font and character set of the table of content in
       CHM files
     + Detailed hint for each node: indicates the URL of the node in the CHM
       file, context number and the topic ID if required
     * When a HND file was opened via the explorer, its name was converted to
       upper case
  
  -> v1.2 - 04/04/2005
     + New file format � HND files are now compressed. Conversion is made behind
       the scenes. Still compatible with old format in read mode
     + Import of HTML, RTF, WRI, and TXT files. DOC files can be imported if
       Microsoft Office is installed on the system
     + Implementation of a better find and replace function: ability to find and
       replace throughout the project
     + Implementation of rudimentary Command line compilation feature: "HelpNDoc
       �c file.hnd"
     + Better CHM generation: Added next and home buttons, advanced search tab,
       addition of the favorite tab
     * Main window's position is now restored when HelpNDoc is launched
     * Better handling of bullets and numbering in the ruler
     * Fixed a bug where < and > characters in the topic title could cause
       compilation error
     + Shortcut to create a new topic, use CTRL+T
     * Confirm save dialog could be displayed many times on application exit

  -> v1.1.1 - 24/02/2005
     * Topic name containing quotes prohibited project from being loaded

  -> v1.1 - 15/02/2005
     + Variables support (known limitation: variables can't be set as hyperlinks)
     + Popup menu in the table of content
     + Help file now contains information on how to integrate CHM files with 
       Delphi and Visual Basic
     + Configuration information are now saved in the registry
     * Page background images weren't exported in CHM
     * Better HTML Help Workshop location handling: ask location when it can't be
       found in the registry
     * Faster CHM export
     * Balloon Hints weren't working in HND 1.0
     * The default icon wasn't always selected when required in the icons popup
       menu
     * The background color and image were not reset when a new topic was created

  -> v1.0 - 12/09/2004
     * Initial Release

== 7. Obtaining technical support ==============================================

Website: http://www.helpndoc.com
E-Mail: support@ibe-software.com

-----------------------------------------
Copyright(c) IBE Software 2003 - 2007